import time
import google.generativeai as genai
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import ElementClickInterceptedException

import config
import os
import shutil
import json
import threading
import keyboard, re
import asyncio

EMAILS_TXT = r"C:\Users\AyushArora\OneDrive - AIR INDIA LIMITED\Desktop\personal\Ayush\Ayush\Automate mail\ayushemail.txt"

if os.path.exists(r"C:\Path\To\Your\SeleniumBraveProfile"):
    shutil.rmtree(r"C:\Path\To\Your\SeleniumBraveProfile")

options = Options()
options.binary_location = config.chrome_path
options.add_argument("--user-data-dir=C:/Users/AyushArora/OneDrive - AIR INDIA LIMITED/Desktop/personal/Ayush/Ayush/Profile3")
options.add_argument("--disable-notifications")
options.add_argument("--disable-popup-blocking")
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 10)

paused = False

def listen_for_pause():
    global paused
    while True:
        if keyboard.is_pressed("p"):
            paused = not paused
            print("Paused" if paused else "Resumed")
            time.sleep(1)

async def callopenAI(job_description):
    genai.configure(api_key="AIzaSyAkWwz-XyCkKlOQJ1brAzOx4tgYEOZDS1I")

    model = genai.GenerativeModel(
        model_name="gemini-3.1-flash-lite-preview",
        system_instruction="""
        Create an email to a recruiter for a job application. The job description and resume are provided.
        Rules:
        1. Express interest and fit
        2. Include resume link in format: For your review, I have attached my resume here: <<<RESUME_LINK>>>
        3. Request a meeting
        4. Return ONLY JSON:
        {
        "subject": "",
        "email": "",
        "ats_score": 0
        }
        5. Start email with "Hello,"
        6. Max 7-8 lines
        7. No placeholders like [Name], [Company]
        8. Resume link must be before regards
        9. Also calculate ATS score (1-10) based on:
        - Skill match with job description (0-6)
        - Experience/relevance match (0-4)
        10. Dont assume that serving notice period.

        Scoring guide:
        - 9-10: Excellent match (all key skills + relevant experience)
        - 7-8: Strong match (most skills + relevant experience)
        - 5-6: Moderate match (some skills + partial relevance)
        - 3-4: Weak match (few skills)
        - 1-2: Poor match (minimal relevance)
        """
    )

    resume = config.resume
    resume_link = config.resume_link

    prompt = f"""
    Job Description Summary: {job_description}
    My Resume: {resume}
    My Resume Link: {resume_link}
    """

    response = model.generate_content(prompt)

    text = response.text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\n?", "", text)
        text = re.sub(r"\n?```$", "", text)
    return text.strip()

def save_to_file(subject, body, recipient_email, post_link="", ats_score=0):
    try:
        with open(EMAILS_TXT, "a", encoding="utf-8") as f:
            for email in recipient_email:
                f.write(email + "\n")
        print(f"Saved to txt: {recipient_email}")
        return True
    except Exception as e:
        print(f"File save error: {e}")
        return False

def close_overlays(driver):
    try:
        close_buttons = [
            "button[aria-label='Dismiss']",
            "button[data-test-modal-close-btn]",
            ".artdeco-modal__dismiss",
            "button.msg-overlay-bubble-header__control"
        ]
        for selector in close_buttons:
            try:
                close_btn = driver.find_element(By.CSS_SELECTOR, selector)
                close_btn.click()
                time.sleep(0.5)
            except:
                pass
    except:
        pass

def safe_click_load_more(driver):
    try:
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if btn.text.strip() == "Load more":
                try:
                    close_overlays(driver)
                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                    time.sleep(0.5)
                    btn.click()
                    print("✓ Clicked 'Load more' button successfully")
                    return True
                except ElementClickInterceptedException:
                    try:
                        driver.execute_script("arguments[0].click();", btn)
                        print("✓ Clicked 'Load more' button using JavaScript")
                        return True
                    except Exception as e:
                        print(f"Failed to click 'Load more' button: {e}")
                        return False
                except Exception as e:
                    print(f"Error clicking 'Load more': {e}")
                    return False
        print("'Load more' button not found")
        return False
    except Exception as e:
        print(f"Error in safe_click_load_more: {e}")
        return False

listener_thread = threading.Thread(target=listen_for_pause, daemon=True)
listener_thread.start()
seen_posts = set()

async def process_jobs():
    try:
        for search_job in config.search_jobs:
            try:
                driver.get(f"https://www.linkedin.com/search/results/content/?keywords=hiring%20{search_job}&origin=FACETED_SEARCH&datePosted=%5B%22past-24h%22%5D")
                time.sleep(2)
                #driver.get(f"https://www.linkedin.com/search/results/content/?keywords=hiring%20{search_job}&origin=FACETED_SEARCH&datePosted=%5B%22past-24h%22%5D")
                
                try:
                    time.sleep(8)
                    close_overlays(driver)

                    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}'

                    for z in range(15):
                        while paused:
                            time.sleep(0.5)

                        try:
                            buttons = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-button"]')
                            for btn in buttons:
                                try:
                                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                                    time.sleep(0.2)
                                    driver.execute_script("arguments[0].click();", btn)
                                except:
                                    pass

                            time.sleep(2)

                            posts = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-box"]')
                            for i, post in enumerate(posts, start=1):
                                text = post.text.strip()
                                if text in seen_posts:
                                    continue

                                seen_posts.add(text)
                                emails = re.findall(email_pattern, text)

                                try:
                                    parent = post.find_element(By.XPATH, "./ancestor::div[contains(@class,'feed-shared-update-v2') or contains(@class,'occludable-update')]")
                                    post_id = parent.get_attribute("data-urn") or parent.get_attribute("data-id") or ""
                                    if post_id:
                                        post_id_clean = post_id.split(":")[-1]
                                        post_link = f"https://www.linkedin.com/feed/update/urn:li:activity:{post_id_clean}/"
                                    else:
                                        post_link = driver.current_url
                                except:
                                    post_link = driver.current_url

                                if len(emails) > 0:
                                    print(f"\n{'='*80}")
                                    print(f"Post {i}: Found {len(emails)} email(s)")
                                    print(f"{'='*80}")

                                    generated_email = await callopenAI(text)

                                    try:
                                        email_response = json.loads(generated_email)

                                        if email_response["ats_score"] > 6:
                                            subject = email_response["subject"]
                                            email_content = email_response["email"]
                                            ats_score = email_response["ats_score"]
                                            print(f"✓ ATS Score: {ats_score} | Recipients: {emails}")

                                            if save_to_file(subject, email_content, emails, post_link, ats_score):
                                                print("✓ Saved to txt!")
                                            else:
                                                print("✗ Failed to save email")
                                        else:
                                            print(f"✗ ATS Score too low: {email_response['ats_score']}")
                                    except json.JSONDecodeError as e:
                                        print(f"JSON decode error: {e}")
                                        continue

                            if not safe_click_load_more(driver):
                                print("No more posts to load, moving to next search")
                                break

                            time.sleep(3)
                            print(f"Iteration {z+1}/15 completed")

                        except Exception as e:
                            print(f"Error in iteration {z}: {e}")
                            continue

                    time.sleep(200)

                except Exception as e:
                    print(f"Error in inner loop: {e}")

            except Exception as e:
                print(f"Exception for search job '{search_job}': {e}")
                continue

    except Exception as e:
        print(f"Exception in process_jobs: {e}")
    finally:
        try:
            driver.quit()
        except:
            pass

asyncio.run(process_jobs())

print("Script completed. Waiting...")
while True:
    time.sleep(300)
