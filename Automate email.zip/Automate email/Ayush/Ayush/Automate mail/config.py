resume = """
Summary
+91 8239714229 
Ayush Arora
GitHub Jaipur, Rajasthan
ayusharora45@gmail.com 
LinkedIn 
Data Engineer with 6 years of experience designing scalable ETL/ELT pipelines, Data Lakehouse architectures, and analytical
data models across financial services, aviation, and enterprise technology domains. Proficient in PySpark, Python, SQL,
Snowflake, Databricks, Delta Lake, Medallion Architecture, and dimensional modeling (Star Schema, SCD) on Azure (ADF,
ADLS Gen2, ADX). Experienced in Spark performance tuning (AQE, Broadcast Join, Window Functions, Query
Optimization), Apache Kafka, Apache Airflow, data quality frameworks, RBAC, PII masking, PCI-DSS/GDPR-aligned
security, CI/CD for data pipelines, Unity Catalog, and Agentic AI development (Claude, OpenAI).
Technical Skills
Languages : Python, PySpark, SQL, T-SQL
Big Data / Spark : Apache Spark, PySpark, Spark SQL, Broadcast Join, Window Functions, Partitioning, Caching,
Adaptive Query Execution (AQE), Spark UI, Query Tuning, Distributed Computing
Streaming / Orchestration : Apache Kafka, Apache Airflow, Event-Driven Pipelines, Workflow Orchestration
Data Platforms : Snowflake, Databricks, Unity Catalog, Azure Data Explorer (ADX), Azure Data Factory (ADF), ADLS
Gen2
Data Lakehouse : Delta Lake, Medallion Architecture (Bronze/Silver/Gold), Parquet, Columnar Storage, Schema
Evolution
Data Modeling : Star Schema, Snowflake Schema, Dimensional Modeling, SCD Type 1/2, CDC, Data Lineage
Security & Compliance : RBAC, PII Masking, Data Encryption, Audit Logging, Threat Modeling, PCI-DSS / GDPR /
SOX Awareness, Security-by-Design
Cloud & DevOps : Microsoft Azure (ADF, ADX, ADLS Gen2, Logic Apps, Databricks), Azure DevOps, GitHub Actions,
CI/CD for Data Pipelines, Cost Optimization
ETL / Integration : ELT Pipeline Design, Batch Processing, SSIS, REST API Integration, Data Ingestion, Data Lineage
Data Quality & Gov. : Data Validation Frameworks, Data Observability, Data Governance, Data Catalog, Audit
Logging, Data Reconciliation
Databases : SQL Server, PostgreSQL, Snowflake, Azure SQL
Testing : Unit Testing, Integration Testing, Data Pipeline Testing, Test-Driven Development
Reporting / BI : Power BI, Microsoft Fabric, Semantic Layer Design
AI / LLM: Claude (Anthropic), Agentic AI, OpenAI, Prompt Engineering, LLM-powered Data Pipelines
Tools : Git, GitHub, VS Code, Visual Studio, Azure Data Studio, SSMS, Postman, PGAdmin, Logic Apps, Amadeus
(PSS), Agile / Scrum
Domain & Leadership : Architecture Governance, Business–IT Alignment, Risk Assessment & Mitigation, Stakeholder
Management, Project Management, Financial Data Processing, Regulatory Reporting, Data Warehouse, Data
Transformation, Data Analytics
Work Experience
Air India
Data Engineer
Sep 2024– Present
• Built 20+ production ELT pipelines on Databricks / PySpark / Delta Lake with Medallion Architecture
(Bronze → Silver → Gold), processing 300+ GB of data daily across booking, financial transaction, and insurance
domains — 40% pipeline performance improvement.
• Architected 80+ Snowflake tables using Star Schema & SCD Type 1/2; applied Partitioning, Caching &
Adaptive Query Execution (AQE) with advanced query tuning reducing runtime from ˜90 to ˜55 minutes on
high-volume tables.
• Built ADX analytics layer on ADLS Gen2 enabling near real-time reporting for 50+ business dashboards,
reducing data reconciliation latency by 35–40%; implemented data quality validation frameworks improving
consistency by 30%.
• Enforced PII masking, RBAC & Unity Catalog governance; conducted threat modeling and security-by-design
reviews for PCI-DSS/GDPR-aligned systems handling sensitive financial and passenger data.
• Established CI/CD via Azure DevOps with unit & integration testing gates; delivered Agentic AI POC using
Claude (Anthropic) for AI-driven data workflows, contributing to enterprise AI adoption roadmap.
• Tech Stack: Python, PySpark, Databricks, Delta Lake, Snowflake, ADF, ADLS Gen2, ADX, Unity Catalog, Azure
DevOps, GitHub Actions, Git, Power BI
MAQ Software
Mar 2023– Aug 2024
Software Engineer 2
• Built 15+ batch pipelines on Databricks / ADX / PySpark with Broadcast Join & Parquet optimizations;
designed Apache Airflow DAGs for pipeline orchestration supplying data to Microsoft Copilot bot for Microsoft
Build and Ignite events.
• Engineered feature engineering pipelines with Window Functions in PySpark for recommendation engine and
LLM-powered chatbot integrating OpenAI APIs; profiled Spark jobs via Spark UI to resolve shuffle bottlenecks.
• Optimised SQL query performance by 40% via execution plan analysis, query tuning, indexing & partitioning;
delivered ETL automation reducing manual effort by 40%.
• Implemented GitHub Actions for pipeline CI/CD; pioneered Azure Content Safety and threat modeling within the
organisation, improving operational efficiency by 25%.
• Tech Stack: Python, PySpark, Databricks, Apache Airflow, ADX, ADF, SQL Server, OpenAI API, GitHub Actions,
Parquet, Git, Power BI
Tata Consultancy Services (TCS)
System Engineer
Aug 2020– Mar 2023
• Designed ETL pipelines using SQL Server, SSIS & Snowflake, reducing manual processing effort by 40% across
financial analytics workloads managing 100+ data tables.
• Built dimensional models (Star Schema, SCD Type 1/2) with Window Functions; applied query tuning and
optimised stored procedures improving performance by 15% and production stability by 20%.
• Used Splunk for pipeline monitoring and data observability; reduced defect resolution costs by 15% through
structured issue triaging and root cause analysis.
• Tech Stack: Python, SQL Server, SSIS, Snowflake, Splunk, T-SQL, SSMS, Git
Education
IET Alwar, Rajasthan (Affiliated to RTU, Kota)
B.Tech in Computer Science & Engineering
Certifications & Awards
2016– 2020
CGPA: 8.4 / 10
• Microsoft Certified: Fabric Analytics Engineer Associate
• Anthropic Certified: Claude Code in Action Anthropic Certified: Claude 101
• AI Star, AI High Flyer & Dream Team Awards — Air India, for scalable data architecture solutions improving
system reliability and performance.
• Star Team Award (Client) & Best Team Award — TCS, for large-scale financial data engineering and
mission-critical program delivery.
• Multiple On-The-Spot Awards — Air India, TCS, MAQ Software, for rapid resolution of production pipeline issues
during critical periods.
• Hackathon Winner (Consecutive) — Academic tenure, for leading data and technology challenge teams.Summary
+91 8239714229 
Ayush Arora
GitHub Jaipur, Rajasthan
ayusharora45@gmail.com 
LinkedIn 
Data Engineer with 6 years of experience designing scalable ETL/ELT pipelines, Data Lakehouse architectures, and analytical
data models across financial services, aviation, and enterprise technology domains. Proficient in PySpark, Python, SQL,
Snowflake, Databricks, Delta Lake, Medallion Architecture, and dimensional modeling (Star Schema, SCD) on Azure (ADF,
ADLS Gen2, ADX). Experienced in Spark performance tuning (AQE, Broadcast Join, Window Functions, Query
Optimization), Apache Kafka, Apache Airflow, data quality frameworks, RBAC, PII masking, PCI-DSS/GDPR-aligned
security, CI/CD for data pipelines, Unity Catalog, and Agentic AI development (Claude, OpenAI).
Technical Skills
Languages : Python, PySpark, SQL, T-SQL
Big Data / Spark : Apache Spark, PySpark, Spark SQL, Broadcast Join, Window Functions, Partitioning, Caching,
Adaptive Query Execution (AQE), Spark UI, Query Tuning, Distributed Computing
Streaming / Orchestration : Apache Kafka, Apache Airflow, Event-Driven Pipelines, Workflow Orchestration
Data Platforms : Snowflake, Databricks, Unity Catalog, Azure Data Explorer (ADX), Azure Data Factory (ADF), ADLS
Gen2
Data Lakehouse : Delta Lake, Medallion Architecture (Bronze/Silver/Gold), Parquet, Columnar Storage, Schema
Evolution
Data Modeling : Star Schema, Snowflake Schema, Dimensional Modeling, SCD Type 1/2, CDC, Data Lineage
Security & Compliance : RBAC, PII Masking, Data Encryption, Audit Logging, Threat Modeling, PCI-DSS / GDPR /
SOX Awareness, Security-by-Design
Cloud & DevOps : Microsoft Azure (ADF, ADX, ADLS Gen2, Logic Apps, Databricks), Azure DevOps, GitHub Actions,
CI/CD for Data Pipelines, Cost Optimization
ETL / Integration : ELT Pipeline Design, Batch Processing, SSIS, REST API Integration, Data Ingestion, Data Lineage
Data Quality & Gov. : Data Validation Frameworks, Data Observability, Data Governance, Data Catalog, Audit
Logging, Data Reconciliation
Databases : SQL Server, PostgreSQL, Snowflake, Azure SQL
Testing : Unit Testing, Integration Testing, Data Pipeline Testing, Test-Driven Development
Reporting / BI : Power BI, Microsoft Fabric, Semantic Layer Design
AI / LLM: Claude (Anthropic), Agentic AI, OpenAI, Prompt Engineering, LLM-powered Data Pipelines
Tools : Git, GitHub, VS Code, Visual Studio, Azure Data Studio, SSMS, Postman, PGAdmin, Logic Apps, Amadeus
(PSS), Agile / Scrum
Domain & Leadership : Architecture Governance, Business–IT Alignment, Risk Assessment & Mitigation, Stakeholder
Management, Project Management, Financial Data Processing, Regulatory Reporting, Data Warehouse, Data
Transformation, Data Analytics
Work Experience
Air India
Data Engineer
Sep 2024– Present
• Built 20+ production ELT pipelines on Databricks / PySpark / Delta Lake with Medallion Architecture
(Bronze → Silver → Gold), processing 300+ GB of data daily across booking, financial transaction, and insurance
domains — 40% pipeline performance improvement.
• Architected 80+ Snowflake tables using Star Schema & SCD Type 1/2; applied Partitioning, Caching &
Adaptive Query Execution (AQE) with advanced query tuning reducing runtime from ˜90 to ˜55 minutes on
high-volume tables.
• Built ADX analytics layer on ADLS Gen2 enabling near real-time reporting for 50+ business dashboards,
reducing data reconciliation latency by 35–40%; implemented data quality validation frameworks improving
consistency by 30%.
• Enforced PII masking, RBAC & Unity Catalog governance; conducted threat modeling and security-by-design
reviews for PCI-DSS/GDPR-aligned systems handling sensitive financial and passenger data.
• Established CI/CD via Azure DevOps with unit & integration testing gates; delivered Agentic AI POC using
Claude (Anthropic) for AI-driven data workflows, contributing to enterprise AI adoption roadmap.
• Tech Stack: Python, PySpark, Databricks, Delta Lake, Snowflake, ADF, ADLS Gen2, ADX, Unity Catalog, Azure
DevOps, GitHub Actions, Git, Power BI
MAQ Software
Mar 2023– Aug 2024
Software Engineer 2
• Built 15+ batch pipelines on Databricks / ADX / PySpark with Broadcast Join & Parquet optimizations;
designed Apache Airflow DAGs for pipeline orchestration supplying data to Microsoft Copilot bot for Microsoft
Build and Ignite events.
• Engineered feature engineering pipelines with Window Functions in PySpark for recommendation engine and
LLM-powered chatbot integrating OpenAI APIs; profiled Spark jobs via Spark UI to resolve shuffle bottlenecks.
• Optimised SQL query performance by 40% via execution plan analysis, query tuning, indexing & partitioning;
delivered ETL automation reducing manual effort by 40%.
• Implemented GitHub Actions for pipeline CI/CD; pioneered Azure Content Safety and threat modeling within the
organisation, improving operational efficiency by 25%.
• Tech Stack: Python, PySpark, Databricks, Apache Airflow, ADX, ADF, SQL Server, OpenAI API, GitHub Actions,
Parquet, Git, Power BI
Tata Consultancy Services (TCS)
System Engineer
Aug 2020– Mar 2023
• Designed ETL pipelines using SQL Server, SSIS & Snowflake, reducing manual processing effort by 40% across
financial analytics workloads managing 100+ data tables.
• Built dimensional models (Star Schema, SCD Type 1/2) with Window Functions; applied query tuning and
optimised stored procedures improving performance by 15% and production stability by 20%.
• Used Splunk for pipeline monitoring and data observability; reduced defect resolution costs by 15% through
structured issue triaging and root cause analysis.
• Tech Stack: Python, SQL Server, SSIS, Snowflake, Splunk, T-SQL, SSMS, Git
Education
IET Alwar, Rajasthan (Affiliated to RTU, Kota)
B.Tech in Computer Science & Engineering
Certifications & Awards
2016– 2020
CGPA: 8.4 / 10
• Microsoft Certified: Fabric Analytics Engineer Associate
• Anthropic Certified: Claude Code in Action Anthropic Certified: Claude 101
• AI Star, AI High Flyer & Dream Team Awards — Air India, for scalable data architecture solutions improving
system reliability and performance.
• Star Team Award (Client) & Best Team Award — TCS, for large-scale financial data engineering and
mission-critical program delivery.
• Multiple On-The-Spot Awards — Air India, TCS, MAQ Software, for rapid resolution of production pipeline issues
during critical periods.
• Hackathon Winner (Consecutive) — Academic tenure, for leading data and technology challenge teams.

Expected Annual CTC(in Lakhs): 20
Current Annual CTC(in Lakhs): 13
Expected Annual CTC(INR): 2000000
Current Annual CTC(INR): 1300000
Expected Annual CTC(USD): 15000
Current Annual CTC(USD): 12000
Notice Period: 60
Serving Notice Period: No
English proficiency: 'Intermediate'
My maximum experience is 6 years only
"""
default_experience = "6"
sender_email = 'ayusharora45@gmail.com'
sender_password = 'cmqd axpc hfrl bljo'
recipient_email = 'ayusharora45@gmail.com'
resume_link = 'https://drive.google.com/file/d/1uhz9jdJ92PkFRlWH4e3KnfVQhwI1TPjb/view?usp=sharing'
# resume_path = r"C:\Users\ShashiShekhar\OneDrive - AIR INDIA LIMITED\Desktop\Personal\Apply\Shashi\Shashi\Shashi_s_Resume.pdf"
search_jobs = [ 
 
     "ETL Developer", "Data Engineer",
        "Senior Data Engineer",
    "Data Platform Engineer",
    "Analytics Engineer","data warehousing" ,"data modeling", "data pipelines", "big data" ,"databricks",
    # Azure Stack
    "Azure Databricks", "Azure Data Engineer",
        "Cloud Data Engineer",
        "Big Data Engineer", 
    "Databricks Engineer",
    "Azure Data Factory",
    "ADF Developer",
    "Azure Synapse",
    "Microsoft Fabric",
    "Fabric Data Engineer",

    # Snowflake
    "Snowflake Data Engineer",
    "Snowflake Developer",

    # Spark
    "PySpark Developer",
    "Spark Developer",
    "Databricks PySpark",

    # ETL
    "ETL Developer",
    "ETL Data Engineer",
    "Data Integration Engineer",
    "Data Pipeline Engineer",

    # Python
    "Python Data Engineer",
    "Python ETL Developer",

    # Architecture
    "Data Architect",
    "Azure Data Architect",
    "Cloud Data Architect",
    "Solution Architect Data",

    # AI/Data
    "AI Data Engineer",
    "ML Data Engineer",
    "GenAI Data Engineer",
    "AI Platform Engineer",

    # Misc
    "Data Warehouse Engineer",
    "Data Lake Engineer",
    "Data Migration Engineer"]
chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
