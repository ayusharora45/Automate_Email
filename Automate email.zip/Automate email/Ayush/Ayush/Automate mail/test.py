import google.generativeai as genai
import config
genai.configure(api_key="AIzaSyCumvXHfjz2Z_su0QXjjY8_k-AvVf_mjrE")

model = genai.GenerativeModel(
    model_name="gemini-3.1-flash-lite-preview",
    system_instruction="""
Create an email to a recruiter for a job application. The job description and resume are provided.
Rules:
1. Express interest and fit
2. Include resume link in format: For your review, I have attached my resume here: <<<RESUME_LINK>>>
3. Request a meeting
4. Return ONLY JSON:
{
  "subject": "",
  "email": "",
  "ats_score": 0
}
5. Start email with "Hello,"
6. Max 7–8 lines
7. No placeholders like [Name], [Company]
8. Resume link must be before regards
9. Also calculate ATS score (1-10) based on:
   - Skill match with job description (0–6)
   - Experience/relevance match (0–4)

   Scoring guide:
   - 9–10: Excellent match (all key skills + relevant experience)
   - 7–8: Strong match (most skills + relevant experience)
   - 5–6: Moderate match (some skills + partial relevance)
   - 3–4: Weak match (few skills)
   - 1–2: Poor match (minimal relevance)
"""
)

job_description = """Job Title: Data Engineer
Location: Remote / Bangalore / Hybrid

🧾 Job Summary

We are looking for a Data Engineer to design, build, and maintain scalable data pipelines and infrastructure. The ideal candidate will work closely with data scientists, analysts, and software engineers to ensure reliable data availability for analytics and machine learning use cases.

🔧 Key Responsibilities
Design, build, and maintain scalable ETL/ELT pipelines
Work with large structured and unstructured datasets
Develop and optimize data warehouse solutions
Ensure data quality, integrity, and security across systems
Collaborate with analytics and ML teams for data requirements
Monitor and improve data pipeline performance and reliability
Implement real-time and batch data processing systems"""
resume = config.resume
resume_link = config.resume_link

prompt = f"""
Job Description Summary: {job_description}
My Resume: {resume}
My Resume Link: {resume_link}
"""

response = model.generate_content(prompt)

print(response.text)