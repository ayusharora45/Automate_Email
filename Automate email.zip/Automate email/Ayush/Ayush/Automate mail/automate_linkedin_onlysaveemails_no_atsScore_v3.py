import time
import csv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import ElementClickInterceptedException, TimeoutException, NoSuchElementException

import config
import os
import shutil
# from extractrecruteremail import load_sent_emails, save_sent_emails
import json
import threading
import keyboard, re
import asyncio
from datetime import datetime

EMAILS_TXT = r"C:\Users\AyushArora\OneDrive - AIR INDIA LIMITED\Desktop\personal\Ayush\Ayush\Automate mail\ayushemail.txt"
# EMAILS_CSV = r"C:\Users\AyushArora\Downloads\ayushemail.csv"

# Remove existing Selenium profile directory if it exists
if os.path.exists(r"C:\Path\To\Your\SeleniumBraveProfile"):
    shutil.rmtree(r"C:\Path\To\Your\SeleniumBraveProfile")

# Set up Chrome options to use Brave browser
options = Options()
options.binary_location = config.chrome_path
options.add_argument("--user-data-dir=C:/Users/AyushArora/OneDrive - AIR INDIA LIMITED/Desktop/personal/Ayush/Ayush/Profile3")
options.add_argument("--disable-notifications")
options.add_argument("--disable-popup-blocking")
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 10)

paused = False

def listen_for_pause():
    global paused
    while True:
        if keyboard.is_pressed("p"):
            paused = not paused
            print("Paused" if paused else "Resumed")
            time.sleep(1)

async def callopenAI(job_description):
    resume_link = config.resume_link

    # Try to extract job title from post text
    title_match = re.search(
        r'(?:hiring|looking for|opening for|position[:\s]+|role[:\s]+|vacancy[:\s]+)\s*[:\-]?\s*([A-Za-z\s/]+(?:Engineer|Developer|Analyst|Manager|Lead|Architect|Designer|Consultant|Specialist|Executive|Officer|Associate|Intern)[A-Za-z\s]*)',
        job_description, re.IGNORECASE
    )
    job_title = title_match.group(1).strip() if title_match else "a Role"

    subject = f"Application for {job_title} - Ayush Arora"
    body = f"""Hello,

I came across your job posting and I am very interested in the {job_title} opportunity. With my experience and skills, I believe I would be a great fit for this role.

For your review, I have attached my resume here: {resume_link}

I would love to schedule a brief meeting to discuss how I can contribute to your team.

Regards,
Ayush Arora"""

    return json.dumps({"subject": subject, "email": body, "ats_score": 7})

def save_to_file(subject, body, recipient_email, post_link="", ats_score=0):
    try:
        # Save emails to txt (one per line)
        with open(EMAILS_TXT, "a", encoding="utf-8") as f:
            for email in recipient_email:
                f.write(email + "\n")

        # # Save full details to CSV
        # file_exists = os.path.exists(EMAILS_CSV)
        # with open(EMAILS_CSV, "a", encoding="utf-8", newline="") as f:
        #     writer = csv.writer(f)
        #     if not file_exists:
        #         writer.writerow(["email", "subject", "body", "post_link", "ats_score"])
        #     for email in recipient_email:
        #         writer.writerow([email, subject, body, post_link, ats_score])

        print(f"Saved to txt: {recipient_email}")
        return True
    except Exception as e:
        print(f"File save error: {e}")
        return False

def close_overlays(driver):
    try:
        close_buttons = [
            "button[aria-label='Dismiss']",
            "button[data-test-modal-close-btn]",
            ".artdeco-modal__dismiss",
            "button.msg-overlay-bubble-header__control"
        ]
        for selector in close_buttons:
            try:
                close_btn = driver.find_element(By.CSS_SELECTOR, selector)
                close_btn.click()
                time.sleep(0.5)
                print(f"Closed overlay using selector: {selector}")
            except:
                pass
    except:
        pass

def safe_click_load_more(driver):
    try:
        buttons = driver.find_elements(By.TAG_NAME, "button")
        for btn in buttons:
            if btn.text.strip() == "Load more":
                try:
                    close_overlays(driver)
                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                    time.sleep(0.5)
                    btn.click()
                    print("✓ Clicked 'Load more' button successfully")
                    return True
                except ElementClickInterceptedException:
                    try:
                        driver.execute_script("arguments[0].click();", btn)
                        print("✓ Clicked 'Load more' button using JavaScript")
                        return True
                    except Exception as e:
                        print(f"Failed to click 'Load more' button: {e}")
                        return False
                except Exception as e:
                    print(f"Error clicking 'Load more': {e}")
                    return False
        print("'Load more' button not found")
        return False
    except Exception as e:
        print(f"Error in safe_click_load_more: {e}")
        return False

listener_thread = threading.Thread(target=listen_for_pause, daemon=True)
listener_thread.start()
seen_posts = set()

async def process_jobs():
    try:
        for search_job in config.search_jobs:
            try:
                job_descriptions = []
                driver.get(f"https://www.linkedin.com/search/results/content/?keywords=hiring%20{search_job}&origin=FACETED_SEARCH&datePosted=%5B%22past-24h%22%5D")
                time.sleep(2)
                job_index = 0
                company_names = []

                try:
                    time.sleep(8)
                    close_overlays(driver)

                    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}'

                    for z in range(15):
                        while paused:
                            time.sleep(0.5)

                        try:
                            buttons = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-button"]')
                            for btn in buttons:
                                try:
                                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                                    time.sleep(0.2)
                                    driver.execute_script("arguments[0].click();", btn)
                                except Exception as e:
                                    pass

                            time.sleep(2)

                            posts = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-box"]')
                            for i, post in enumerate(posts, start=1):
                                text = post.text.strip()
                                if text in seen_posts:
                                    continue

                                seen_posts.add(text)
                                emails = re.findall(email_pattern, text)
                                # sent_emails = load_sent_emails()
                                # emails = [email for email in emails if email not in sent_emails]

                                # Try to get post link from parent element
                                try:
                                    parent = post.find_element(By.XPATH, "./ancestor::div[contains(@class,'feed-shared-update-v2') or contains(@class,'occludable-update')]")
                                    post_id = parent.get_attribute("data-urn") or parent.get_attribute("data-id") or ""
                                    if post_id:
                                        post_id_clean = post_id.split(":")[-1]
                                        post_link = f"https://www.linkedin.com/feed/update/urn:li:activity:{post_id_clean}/"
                                    else:
                                        post_link = driver.current_url
                                except:
                                    post_link = driver.current_url

                                if len(emails) > 0:
                                    print(f"\n{'='*80}")
                                    print(f"Post {i}: Found {len(emails)} email(s)")
                                    print(f"{'='*80}")

                                    generated_email = await callopenAI(text)
                                    # print(generated_email)

                                    try:
                                        email_response = json.loads(generated_email)

                                        if email_response["ats_score"] > 6:
                                            subject = email_response["subject"]
                                            email_content = email_response["email"]
                                            ats_score = email_response["ats_score"]
                                            print(f"✓ ATS Score: {ats_score} | Recipients: {emails}")
                                            # print(f"Subject: {subject}")

                                            if save_to_file(subject, email_content, emails, post_link, ats_score):
                                                # save_sent_emails(emails)
                                                print("✓ Saved to txt!")
                                            else:
                                                print("✗ Failed to save email")
                                        else:
                                            print(f"✗ ATS Score too low: {email_response['ats_score']}")
                                    except json.JSONDecodeError as e:
                                        print(f"JSON decode error: {e}")
                                        continue

                            if not safe_click_load_more(driver):
                                print("No more posts to load, moving to next search")
                                break

                            time.sleep(3)
                            print(f"Iteration {z+1}/15 completed")

                        except Exception as e:
                            print(f"Error in iteration {z}: {e}")
                            continue

                    time.sleep(200)

                except Exception as e:
                    print(f"Error in inner loop: {e}")

            except Exception as e:
                print(f"Exception for search job '{search_job}': {e}")
                continue

    except Exception as e:
        print(f"Exception in process_jobs: {e}")
    finally:
        try:
            driver.quit()
        except:
            pass

asyncio.run(process_jobs())

print("Script completed. Waiting...")
while True:
    time.sleep(300)
