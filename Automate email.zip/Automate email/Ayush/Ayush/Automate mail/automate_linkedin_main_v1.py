import time
import google.generativeai as genai
from selenium import webdriver

EMAILS_TXT = r"C:\Users\AyushArora\OneDrive - AIR INDIA LIMITED\Desktop\personal\Ayush\Ayush\Automate mail\ayushemail.txt"
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options

import config
import os
import shutil
from extractrecruteremail import load_sent_emails, save_sent_emails
import json
import threading
import keyboard, re
import asyncio
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders


# Remove existing Selenium profile directory if it exists
if os.path.exists(r"C:\Path\To\Your\SeleniumBraveProfile"):
    shutil.rmtree(r"C:\Path\To\Your\SeleniumBraveProfile")

# Set up Chrome options to use Brave browser
options = Options()
options.binary_location = config.chrome_path
# options.add_argument("--user-data-dir=C:/Users/AyushArora/Downloads/Profile3")
options.add_argument("--user-data-dir=C:/Users/AyushArora/OneDrive - AIR INDIA LIMITED/Desktop/personal/Ayush/Ayush/Profile2")
# Initialize the WebDriver
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 4)


# Shared pause flag
paused = False

# Background thread to watch for key press
def listen_for_pause():
    global paused
    while True:
        if keyboard.is_pressed("p"):
            paused = not paused
            print("Paused" if paused else "Resumed")
            time.sleep(1)  # debounce delay

async def callopenAI(job_description):
    genai.configure(api_key="AIzaSyAkWwz-XyCkKlOQJ1brAzOx4tgYEOZDS1I")

    model = genai.GenerativeModel(
    model_name="gemini-3.1-flash-lite-preview",
    # model_name="gemma-3-2b",
    # model_name="gemini-2.5-flash",
    system_instruction="""
        Create an email to a recruiter for a job application. The job description and resume are provided.
        Rules:
        1. Express interest and fit
        2. Include resume link in format: For your review, I have attached my resume here: <<<RESUME_LINK>>>
        3. Request a meeting
        4. Return ONLY JSON:
        {
        "subject": "",
        "email": "",
        "ats_score": 0
        }
        5. Start email with "Hello,"
        6. Max 7–8 lines
        7. No placeholders like [Name], [Company]
        8. Resume link must be before regards
        9. Also calculate ATS score (1-10) based on:
        - Skill match with job description (0–6)
        - Experience/relevance match (0–4)
        10. Dont assume that serving notice period.

        Scoring guide:
        - 9–10: Excellent match (all key skills + relevant experience)
        - 7–8: Strong match (most skills + relevant experience)
        - 5–6: Moderate match (some skills + partial relevance)
        - 3–4: Weak match (few skills)
        - 1–2: Poor match (minimal relevance)
        """
        )

    resume = config.resume
    resume_link = config.resume_link

    prompt = f"""
    Job Description Summary: {job_description}
    My Resume: {resume}
    My Resume Link: {resume_link}
    """

    response = model.generate_content(prompt)

    return response.text

def send_email(subject, body, recipient_email):
    # Create the email header
    msg = MIMEMultipart()
    msg['From'] = config.sender_email
    # msg['To'] = recipient_email
    msg['To'] = ", ".join(recipient_email)
    # msg['To'] = config.recipient_email
    msg['Subject'] = subject

    # Attach the email body
    msg.attach(MIMEText(body, 'plain'))

    # Attach the resume file
    # file_path = config.resume_path
    # if os.path.isfile(file_path):  # Ensure the file exists
    #     try:
    #         with open(file_path, 'rb') as attachment:
    #             part = MIMEBase('application', 'octet-stream')
    #             part.set_payload(attachment.read())
    #             encoders.encode_base64(part)
    #             part.add_header(
    #                 'Content-Disposition',
    #                 f'attachment; filename={os.path.basename(file_path)}',
    #             )
    #             msg.attach(part)
    #     except Exception as e:
    #         print(f"Failed to attach file {file_path}: {e}")
    # else:
    #     print(f"File {file_path} does not exist.")


    # Setup the SMTP server
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Secure the connection
        server.login(config.sender_email, config.sender_password)  # Login to the email account
        text = msg.as_string()  # Convert the message to a string
        server.sendmail(config.sender_email, recipient_email, text)  # Send the email
        server.quit()  # Close the SMTP server connection
        return True
    except Exception as e:
        return False

# Start listener thread
listener_thread = threading.Thread(target=listen_for_pause, daemon=True)
listener_thread.start()
seen_posts = set()

# Send initial email notification
async def process_jobs():
    for search_job in config.search_jobs:
        try:
            job_descriptions = []
            # Apply a 1-day filter and easy apply filter for jobs r86400 1 day
            # driver.get(f"https://www.linkedin.com/search/results/content/?keywords=hiring%20{search_job}%20onsite%20opportunity&origin=FACETED_SEARCH&datePosted=%5B%22past-24h%22%5D")
            driver.get(f"https://www.linkedin.com/search/results/content/?keywords=hiring%20{search_job}&origin=FACETED_SEARCH&datePosted=%5B%22past-24h%22%5D")
            time.sleep(2)
            job_index = 0
            company_names = []

            try:
                # Step 1: Open Hiring Manager Profile
                time.sleep(8)

                # 3. Extract posts + emails
                

                email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}'
                for z in range(15):
                    # 1. Click all "… more" buttons
                    buttons = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-button"]')

                    for btn in buttons:
                        try:
                            driver.execute_script("arguments[0].style.pointerEvents = 'auto';", btn)
                            driver.execute_script("arguments[0].click();", btn)
                        except Exception as e:
                            print("Click failed:", e)

                    # 2. Wait for DOM update
                    time.sleep(2)  # adjust if needed

                    posts = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-box"]')
                    for i, post in enumerate(posts, start=1):
                        text = post.text.strip()
                        # 🔥 skip already processed posts
                        if text in seen_posts:
                            continue

                        seen_posts.add(text)
                        emails = re.findall(email_pattern, text)
                        sent_emails = load_sent_emails()
                        emails = [email for email in emails if email not in sent_emails]
                        
                        if len(emails)>0:
                            print(f"Post_________________________________________________ {text}:")
                            generated_email = await callopenAI(text)
                            print(generated_email)
                            email_response = json.loads(generated_email)
                            # emails =["shashi.shekhar.87890@gmail.com"]
                            
                            if email_response["ats_score"] > 6:
                                # # Convert the generated email response to JSON
                                subject = email_response["subject"]
                                email_content = email_response["email"]
                                print("Email Subject:", subject)
                                print("Email Content:", email_content)
                                print("Email Recipient:", emails)
                                # Send the email
                                if send_email(subject, email_content, emails):
                                    # driver.quit()
                                    save_sent_emails(emails)
                                with open(EMAILS_TXT, "a", encoding="utf-8") as f:
                                    for email in emails:
                                        f.write(email + "\n")

                    buttons = driver.find_elements(By.TAG_NAME, "button")

                    for btn in buttons:
                        if btn.text.strip() == "Load more":
                            btn.click()
                            break
                    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", z)
                time.sleep(200)
            except Exception as e: # Handle exceptions
                print("Error:", e)
                driver.quit()
        except Exception as e:
            print("Exception at outer loop", e)

asyncio.run(process_jobs())
while True:
    time.sleep(300)


