# OLD VERSION - uses SMTP for email (blocked on company VPN). Use Automate11111_new.py instead.

import time

EMAILS_TXT = r"C:\Users\AyushArora\OneDrive - AIR INDIA LIMITED\Desktop\personal\Ayush\Ayush\Automate mail\ayushemail.txt"
from google import genai
from google.genai import types
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import ElementClickInterceptedException, TimeoutException, NoSuchElementException

import config
import os
import shutil
from extractrecruteremail import load_sent_emails, save_sent_emails
import json
import threading
import keyboard, re
import asyncio
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders


# Remove existing Selenium profile directory if it exists
if os.path.exists(r"C:\Path\To\Your\SeleniumBraveProfile"):
    shutil.rmtree(r"C:\Path\To\Your\SeleniumBraveProfile")

# Set up Chrome options to use Brave browser
options = Options()
options.binary_location = config.chrome_path
options.add_argument("--user-data-dir=C:/Users/AyushArora/OneDrive - AIR INDIA LIMITED/Desktop/personal/Ayush/Ayush/Profile3")
options.add_argument("--disable-notifications")  # Disable notification popups
options.add_argument("--disable-popup-blocking")
# Initialize the WebDriver
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 10)


# Shared pause flag
paused = False

# Background thread to watch for key press
def listen_for_pause():
    global paused
    while True:
        if keyboard.is_pressed("p"):
            paused = not paused
            print("Paused" if paused else "Resumed")
            time.sleep(1)  # debounce delay

async def callopenAI(job_description):
    client = genai.Client(api_key="AIzaSyAAK4XlcLZQuN9e8c7OM9u4jOVJAYhwuuMg")

    resume = config.resume
    resume_link = config.resume_link

    prompt = f"""
    Job Description Summary: {job_description}
    My Resume: {resume}
    My Resume Link: {resume_link}
    """

    for attempt in range(5):
        try:
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                config=types.GenerateContentConfig(
                    system_instruction="""
            Create an email to a recruiter for a job application. The job description and resume are provided.
            Rules:
            1. Express interest and fit
            2. Include resume link in format: For your review, I have attached my resume here: <<<RESUME_LINK>>>
            3. Request a meeting
            4. Return ONLY JSON:
            {
            "subject": "",
            "email": "",
            "ats_score": 0
            }
            5. Start email with "Hello,"
            6. Max 7–8 lines
            7. No placeholders like [Name], [Company]
            8. Resume link must be before regards
            9. Also calculate ATS score (1-10) based on:
            - Skill match with job description (0–6)
            - Experience/relevance match (0–4)
            10. Dont assume that serving notice period.

            Scoring guide:
            - 9–10: Excellent match (all key skills + relevant experience)
            - 7–8: Strong match (most skills + relevant experience)
            - 5–6: Moderate match (some skills + partial relevance)
            - 3–4: Weak match (few skills)
            - 1–2: Poor match (minimal relevance)
            """
                ),
                contents=prompt
            )

            text = response.text.strip()
            if text.startswith("```"):
                text = re.sub(r"^```(?:json)?\n?", "", text)
                text = re.sub(r"\n?```$", "", text)
            return text.strip()

        except Exception as e:
            error_str = str(e)
            if "429" in error_str or "RESOURCE_EXHAUSTED" in error_str:
                # Extract retry delay from error message
                match = re.search(r"Please retry in (\d+\.?\d*)s", error_str)
                wait = float(match.group(1)) + 5 if match else 60
                print(f"Rate limited. Waiting {wait:.0f}s before retry (attempt {attempt+1}/5)...")
                time.sleep(wait)
            else:
                raise

    raise Exception("Gemini API failed after 5 retries")

def send_email(subject, body, recipient_email):
    # Create the email header
    msg = MIMEMultipart()
    msg['From'] = config.sender_email
    msg['To'] = ", ".join(recipient_email)
    msg['Subject'] = subject

    # Attach the email body
    msg.attach(MIMEText(body, 'plain'))

    # Setup the SMTP server
    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(config.sender_email, config.sender_password)  # Login to the email account
        text = msg.as_string()  # Convert the message to a string
        server.sendmail(config.sender_email, recipient_email, text)  # Send the email
        server.quit()  # Close the SMTP server connection
        return True
    except Exception as e:
        print(f"Email send error: {e}")
        return False

def close_overlays(driver):
    """Close any LinkedIn overlays/modals that might block clicks"""
    try:
        # Try to find and close common LinkedIn overlays
        close_buttons = [
            "button[aria-label='Dismiss']",
            "button[data-test-modal-close-btn]",
            ".artdeco-modal__dismiss",
            "button.msg-overlay-bubble-header__control"
        ]

        for selector in close_buttons:
            try:
                close_btn = driver.find_element(By.CSS_SELECTOR, selector)
                close_btn.click()
                time.sleep(0.5)
                print(f"Closed overlay using selector: {selector}")
            except:
                pass

    except Exception as e:
        pass  # No overlay to close

def safe_click_load_more(driver):
    """Safely click 'Load more' button with multiple fallback strategies"""
    try:
        buttons = driver.find_elements(By.TAG_NAME, "button")

        for btn in buttons:
            if btn.text.strip() == "Load more":
                try:
                    # Strategy 1: Close any overlays first
                    close_overlays(driver)

                    # Strategy 2: Scroll button into view
                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                    time.sleep(0.5)

                    # Strategy 3: Try regular click
                    btn.click()
                    print("✓ Clicked 'Load more' button successfully")
                    return True

                except ElementClickInterceptedException:
                    try:
                        # Strategy 4: JavaScript click as fallback
                        driver.execute_script("arguments[0].click();", btn)
                        print("✓ Clicked 'Load more' button using JavaScript")
                        return True
                    except Exception as e:
                        print(f"Failed to click 'Load more' button: {e}")
                        return False
                except Exception as e:
                    print(f"Error clicking 'Load more': {e}")
                    return False

        print("'Load more' button not found")
        return False

    except Exception as e:
        print(f"Error in safe_click_load_more: {e}")
        return False

# Start listener thread
listener_thread = threading.Thread(target=listen_for_pause, daemon=True)
listener_thread.start()
seen_posts = set()

# Send initial email notification
async def process_jobs():
    try:
        for search_job in config.search_jobs:
            try:
                job_descriptions = []
                driver.get(f"https://www.linkedin.com/search/results/content/?keywords=hiring%20{search_job}&origin=FACETED_SEARCH&datePosted=%5B%22past-24h%22%5D")
                time.sleep(2)
                job_index = 0
                company_names = []

                try:
                    # Step 1: Open Hiring Manager Profile
                    time.sleep(8)

                    # Close any initial overlays
                    close_overlays(driver)

                    # 3. Extract posts + emails
                    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}'

                    for z in range(15):
                        # Check if paused
                        while paused:
                            time.sleep(0.5)

                        try:
                            # 1. Click all "… more" buttons
                            buttons = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-button"]')

                            for btn in buttons:
                                try:
                                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                                    time.sleep(0.2)
                                    driver.execute_script("arguments[0].click();", btn)
                                except Exception as e:
                                    pass  # Continue if one button fails

                            # 2. Wait for DOM update
                            time.sleep(2)

                            posts = driver.find_elements(By.CSS_SELECTOR, '[data-testid="expandable-text-box"]')
                            for i, post in enumerate(posts, start=1):
                                text = post.text.strip()
                                # Skip already processed posts
                                if text in seen_posts:
                                    continue

                                seen_posts.add(text)
                                emails = re.findall(email_pattern, text)
                                sent_emails = load_sent_emails()
                                emails = [email for email in emails if email not in sent_emails]

                                if len(emails) > 0:
                                    print(f"\n{'='*80}")
                                    print(f"Post {i}: Found {len(emails)} email(s)")
                                    print(f"{'='*80}")

                                    generated_email = await callopenAI(text)
                                    print(generated_email)

                                    try:
                                        email_response = json.loads(generated_email)

                                        if email_response["ats_score"] > 6:
                                            subject = email_response["subject"]
                                            email_content = email_response["email"]
                                            print(f"✓ ATS Score: {email_response['ats_score']}")
                                            print(f"Subject: {subject}")
                                            print(f"Recipients: {emails}")

                                            # Send the email
                                            if send_email(subject, email_content, emails):
                                                save_sent_emails(emails)
                                                print("✓ Email sent successfully!")
                                            else:
                                                print("✗ Failed to send email")
                                            with open(EMAILS_TXT, "a", encoding="utf-8") as f:
                                                for email in emails:
                                                    f.write(email + "\n")
                                        else:
                                            print(f"✗ ATS Score too low: {email_response['ats_score']}")
                                    except json.JSONDecodeError as e:
                                        print(f"JSON decode error: {e}")
                                        continue

                            # Try to load more posts
                            if not safe_click_load_more(driver):
                                print("No more posts to load, moving to next search")
                                break

                            time.sleep(3)  # Wait for new posts to load
                            print(f"Iteration {z+1}/15 completed")

                        except Exception as e:
                            print(f"Error in iteration {z}: {e}")
                            # Don't quit on iteration error, continue to next iteration
                            continue

                    time.sleep(200)

                except Exception as e:
                    print(f"Error in inner loop: {e}")
                    # Don't quit driver here, continue to next search job

            except Exception as e:
                print(f"Exception for search job '{search_job}': {e}")
                continue

    except Exception as e:
        print(f"Exception in process_jobs: {e}")
    finally:
        # Clean up
        try:
            driver.quit()
        except:
            pass

asyncio.run(process_jobs())

print("Script completed. Waiting...")
while True:
    time.sleep(300)



