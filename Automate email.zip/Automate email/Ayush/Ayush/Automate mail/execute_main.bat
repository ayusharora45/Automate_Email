cd "C:\Users\v-shashishek\Desktop\tmp\test\Automate apply process v7"
py "Automate - main - Linkdin.py"
Pause