from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import time
import re
import httpx
import config
from groq import Groq
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import json
import os
import shutil

def sleep(seconds):
    time.sleep(seconds)

def normalize_string(s):
    return ''.join(e.lower() for e in s if e.isalnum())

def calculate_match_score(user_name, email):
    normalized_user_name = normalize_string(user_name)
    local_part = email.split('@')[0]
    normalized_local_part = normalize_string(local_part)
    
    match_score = 0
    if normalized_user_name in normalized_local_part:
        match_score += 50
    return match_score


EMAIL_TRACK_FILE = r"C:\Users\AyushArora\Downloads\tmp.txt"

def load_sent_emails():
    """Load the list of emails already sent from the file."""
    if os.path.exists(EMAIL_TRACK_FILE):
        with open(EMAIL_TRACK_FILE, "r") as file:
            return set(line.strip() for line in file)
    return set()

def save_sent_emails(emails):
    """Save a list of emails to the file to mark them as sent."""

    with open(EMAIL_TRACK_FILE, "a") as file:
        for email in emails:
            file.write(email + "\n")


def extractrecruteremail(url, jd):
    brave_path = r"C:\Users\ShashiShekhar\AppData\Local\BraveSoftware\Brave-Browser\Application\brave.exe"

    # Remove existing Selenium profile directory if it exists
    if os.path.exists(r"C:\Path\To\Your\SeleniumBraveProfile"):
        shutil.rmtree(r"C:\Path\To\Your\SeleniumBraveProfile")

    # Set up Chrome options to use Brave browser
    options = Options()
    options.binary_location = brave_path
    options.add_argument("--user-data-dir=C:/Users/ShashiShekhar/AppData/Local/BraveSoftware/Brave-Browser/Application/Profile3")

    driver = webdriver.Chrome(options=options)
    try:
        # Step 1: Open Hiring Manager Profile
        driver.get(url)  # Replace with the actual URL
        sleep(8)

        first_hirer_info_element = driver.find_element(By.CSS_SELECTOR, ".hirer-card__hirer-information")
        # app_aware_link = first_hirer_info_element.find_element(By.CSS_SELECTOR, ".JfQWFCeQjMXQDVSMwMGKHIHLKZfgSeTo")
        app_aware_link = first_hirer_info_element.find_element(By.TAG_NAME, "a")
        app_aware_link.click()
        sleep(5)
        
        # Step 2: Click "See all posts" button
        see_all_post_buttons = driver.find_elements(By.CSS_SELECTOR, '.artdeco-card.pv-profile-card.break-words.mt2 footer a')
        for button in see_all_post_buttons:
            button.click()
        sleep(3)
        
        # Step 3: Click "Show more" button in each post
        show_more_buttons = driver.find_elements(By.CLASS_NAME, 'feed-shared-inline-show-more-text__see-more-less-toggle.see-more.t-14.t-black--light.t-normal.hoverable-link-text')
        for button in show_more_buttons:
            print('Button text before click:', button.text.strip())
            button.click()

        # Step 4: Extract email of the hiring manager from posts
        email_regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com\b'
        post_containers = driver.find_elements(By.CLASS_NAME, "display-flex.flex-wrap.list-style-none.justify-center")
        emails = []

        matches = re.findall(email_regex, jd)
        if matches:
            for email in matches:
                emails.append(email)
                
        for container in post_containers:
            text_content = container.text
            matches = re.findall(email_regex, text_content)
            if matches:
                for email in matches:
                    emails.append(email)
        emails = list(set(emails))
        print("Extracted Emails:", emails)

        # Step 5: Extract Name of the Hiring Manager
        name_elements = driver.find_elements(By.CLASS_NAME, "single-line-truncate.t-16.t-black.t-bold.mt2")
        if name_elements:
            name = name_elements[0].text.strip()
            print("Extracted Name:", name)
        else:
            name = ""

        # Step 6: Match the score of name and email
        if name and emails:
            email_scores = [(email, calculate_match_score(name, email)) for email in emails]
            max_score = max(score for _, score in email_scores)
            max_score_emails = [email for email, score in email_scores if score == max_score]

            emails = max_score_emails

        sent_emails = load_sent_emails()
        print("Sent: ",sent_emails)
        emails = [email for email in emails if email not in sent_emails]

        if len(emails)>0:
            print("Emails found")
            generated_email = callopenAI(jd)
            print("Generated Email:", generated_email)
            # # Convert the generated email response to JSON
            email_response = json.loads(generated_email)
            subject = email_response["subject"]
            email_content = email_response["email"]
            print("Email Subject:", subject)
            print("Email Content:", email_content)
            print("Email Recipient:", emails)
            
            # Send the email
            if send_email(subject, email_content, emails):
                driver.quit()
                save_sent_emails(emails)
                return True
    except Exception as e: # Handle exceptions
        print("Error:", e)
        driver.quit()
        return False
        


def callopenAI(job_description):
    client = Groq(
        api_key="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",
    )

    response = client.chat.completions.create(
        model="llama3-8b-8192",
        temperature=0.1,
        top_p=0.7,
        response_format={"type": "json_object"},
        messages=[
            {
                "role": "system",
                "content": 
                """
                Create an email to a recruiter for a job application. The job description and my resume highlights are below. Please draft a professional email that:
                1. Express my interest in the job and why I’m a good fit.
                2. Add resume link in the mail like "For your review, I have attached my resume here: <<<[My Resume Link]>>>".
                3. Requests a meeting or further discussion.
                4. Return the email in following json format showmn example below:
                {
                    "subject": "",
                    "email": ""
                }

                ##Dont create template for this email. Just draft the email and if some details are missing skip that part.
                It should be a professional email and maximum of 7 to 8 lines.
                ## Dont use any placeholders like [Recruiter's Name], [Name], [Company Name], [Job Title] etc. Just draft the email.
                ## Please make sure to add the resume link at the end of the email and before regards.
                ## Start the email with "Hello,".
                ## Validate the email content and make sure resume link is attached.
                ## Do no exagerate the skills that are not present in the resume.
                """
            },
            {
                "role": "user",
                "content": f"""Job Description Summary: <<<{job_description}>>>
                            My Resume:<<<{config.resume}>>>
                            My Resume Link:<<<{config.resume_link}>>>
                """
            }
        ],
        timeout=httpx.Timeout(30.0, connect=5.0),
    )
    classifier_output = response.choices[0].message.content
    return classifier_output


def send_email(subject, body, recipient_email):
    # Create the email header
    msg = MIMEMultipart()
    msg['From'] = config.sender_email
    # msg['To'] = recipient_email
    msg['To'] = ", ".join(recipient_email)
    # msg['To'] = config.recipient_email
    msg['Subject'] = subject

    # Attach the email body
    msg.attach(MIMEText(body, 'plain'))

    file_path = config.resume_path
    if os.path.isfile(file_path):  # Ensure the file exists
        try:
            with open(file_path, 'rb') as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename={os.path.basename(file_path)}',
                )
                msg.attach(part)
        except Exception as e:
            print(f"Failed to attach file {file_path}: {e}")
    else:
        print(f"File {file_path} does not exist.")


    # Setup the SMTP server
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Secure the connection
        server.login(config.sender_email, config.sender_password)  # Login to the email account
        text = msg.as_string()  # Convert the message to a string
        server.sendmail(config.sender_email, recipient_email, text)  # Send the email
        server.quit()  # Close the SMTP server connection
        return True
    except Exception as e:
        return False


# extractrecruteremail("https://www.linkedin.com/jobs/collections/recommended/?currentJobId=4197131000", """About the job
# Responsibilities: 
# Design, build, and maintain data pipelines.
# Develop ETL processes for data integration.
# Build and optimize data warehouses and lakes.
# Ensure data quality and security.
# Collaborate with data scientists and analysts.


# Requirements: 
# Bachelor's degree in CS or related field.
# Experience with SQL, Python, and big data technologies.
# Proficiency in cloud platforms (AWS, GCP, Azure).
# Strong problem-solving and communication skills.""")
