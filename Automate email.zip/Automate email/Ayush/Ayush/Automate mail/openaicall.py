from openai import AzureOpenAI
import httpx
import config
from groq import Groq
def get_openai_response(resume, question):
    # client = AzureOpenAI(
    #     api_key="e2b02b58eb2948768b1103fea0b65082",
    #     api_version="2024-03-01-preview",
    #     azure_endpoint="https://eventsassistant.openai.azure.com/",
    # )
    client = Groq(
        api_key="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",
    )

    response = client.chat.completions.create(
        # model="gpt-35-turbo-16k-new",
        model="llama3-8b-8192",
        temperature=0.1,
        top_p=0.7,
        messages=[
            {
                "role": "system",
                "content": 
                f"""You are a bot that helps filling the responses for questions asked while applying for the job.
                1. If question is about experience years and no options are provided, return 2 if there is no relavent experience.
                2. If the questions asking about numbers or experience years, return the exact number. If not experience return 2. If question is about skills, return the skills in a list.
                3. If the question is about compatibitlity with the job like location, Are you comfortable commuting to this job's location?, Working days for this position are 6 days. Do you agree?, etc return 'Yes'.
                ### Note: Assume the job i am applying for, I fullfill all the requirements.
                ### Note: If options are provided with the question, select the most appropriate answer from the options based on the resume content. If none of the options are exactly appropriate, select the closest or most relevant option. If no options are provided, respond with the most accurate answer based on the resume content.
                
                
                Given the resume content provided:\n{resume}
                """
            },
            {
                "role": "user",
                "content": f"Respond to the exact value only for question: {question}."
            }
        ],
        timeout=httpx.Timeout(30.0, connect=5.0),
    )
    classifier_output = response.choices[0].message.content
    if "0" == classifier_output and  "experience" in question.lower():
        classifier_output = config.defalut_experience
    return classifier_output

# print(get_openai_response(config.resume,"""Experience in React"""))



def get_ats_openai_response(resume, jd):
    # client = AzureOpenAI(
    #     api_key="e2b02b58eb2948768b1103fea0b65082",
    #     api_version="2024-03-01-preview",
    #     azure_endpoint="https://eventsassistant.openai.azure.com/",
    # )
    client = Groq(
        api_key="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",
    )

    response = client.chat.completions.create(
        # model="gpt-35-turbo-16k-new",
        model="llama3-8b-8192",
        temperature=0.1,
        top_p=0.7,
        messages=[
            {
                "role": "system",
                "content": 
                f"""You will receive the following inputs:
                        Resume: Candidate's resume.
                        Job Descriptions (JD): Job descriptions for open positions.

                    Scoring Criteria:
                        Skills Match (0–2):
                            0: No skills match.
                            1: Partial match.
                            2: Full match.

                        Relevant Experience (0–2):
                            0: Significant experience mismatch.
                            1: Partial relevant experience.
                            2: Full relevant experience.

                        Language and Visa Restrictions (0–2):
                            0: Job has language or visa restrictions.
                            2: No restrictions.

                        Job Description Language (0–2):
                            0: JD is not in English.
                            2: JD is in English.

                    Instructions:
                        Only generate the output in json in provided format.
                        ### dont generate anything else not even any justification.
                        The output should be a JSON object with the following structure:
                        {{
                            "Skills Match": <score>,
                            "Relevant Experience": <score>,
                            "Language and Visa Restrictions": <score>,
                            "Job Description Language": <score>
                        }}
                
                Given the resume content provided:\n{resume}
                """
            },
            {
                "role": "user",
                "content": f"Following is the job description: {jd}."
            }
        ],
        timeout=httpx.Timeout(30.0, connect=5.0),
    )
    classifier_output = response.choices[0].message.content
    # if "0" == classifier_output and  "experience" in question.lower():
    #     classifier_output = config.defalut_experience
    return classifier_output