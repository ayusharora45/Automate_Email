resume = """
Rishika Arora
LinkedIn
JAVA DEVELOPER
Location: Ajmer, Rajasthan, India
Email: arishika382@gmail.com | Mobile: 8209132875
Java Developer with 2.5+ yearsofexperience building scalable, secure backend services for a production Event Management
System. Strong in CoreJava,SpringBoot,andRESTAPIdevelopment,withhands-onworkinpayment-gatewayintegration,
booking workflows,ORM-baseddataaccess(Hibernate/JPA), and Spring Security with JWT. Comfortable working within a
microservices-based environment and eager to deepen distributed-systems expertise in a growth-oriented organization.
TECHNICAL SKILLS
Languages
Frameworks
Technologies
AI/GenAI
Databases
DevTools
EXPERIENCE
:
:
:
:
:
:
Java, PHP, JavaScript, HTML, CSS
Spring Boot, Spring MVC, Spring Security, Hibernate, JPA
Microservices, REST API, JWT, OOPs, Java 8 (Streams, Lambda)
Agentic AI, Prompt Engineering
MySQL,MongoDB
IntelliJ IDEA, Maven, Git, Postman
Java Developer
Metagauss
Product: Event ManagementSystem(eventcreation, booking & payments)
December 2023–April2026
Jaipur, Rajasthan, India
• Built andmaintainedscalable backendservices for a production Event ManagementSystemusingCoreJavaand
Spring Boot, supporting 500+daily bookingsduringpeakeventtraffic
• Designedandmaintained15+RESTfulAPIsforcommunicationbetweenbackendservicesandfrontend
applications, following REST best practices and standardized HTTP status codes
• Integrated AmazonPayintothebookingandpaymentmoduleviaSpringBootRESTAPIs,handlingthefull
payment lifecycle (request initiation, response processing, real-time status updates in MySQL) while ensuring data
consistency during failures and cancellations
• Developeddynamicbooking-amountcalculationlogic andareusablecountdown-timerfeature for event bookings,
exposed through secure REST APIs and reused across multiple event pages
• ImplementedORM-baseddataaccesswithHibernateandJPAoverMySQLandMongoDB,optimizingqueriesfor
faster response times
• SecuredRESTAPIendpointsusingSpringSecurityandJWT-basedauthenticationwithrole-basedaccesscontrol
(RBAC); debuggedandresolved20+productionbookingandpaymentissuesbyanalyzinglogsanddatabase
records
• Workedwithinamicroservices-based environment, building and maintaining booking and paymentAPIsin
coordination with shared service-discovery and API-gateway components
PROJECTS
E-CommerceBackendSystem
Spring Boot, Microservices, MySQL, MongoDB, JWT, Eureka, Git
• DevelopedascalableE-CommerceBackendSystemusingSpringBootandMicroservicesarchitecture,separating
modulesfor User, Product, Order, and Paymentservices
• ImplementedJWT-basedauthenticationandauthorization using Spring Security to secure all API endpoints across
services
• ConfiguredEurekaServiceDiscoveryandAPIGatewayfordynamicserviceregistration, load balancing, and
centralized request routing
• UsedMySQLforrelationaldata(users, orders) and MongoDBforunstructureddata(product catalog), optimizing
queries using Hibernate and JPA
EDUCATION
Govt. Women’sEngineeringCollege,BikanerTechnicalUniversity
B.Tech in Information Technology
All Saints School (CBSE)
Senior Secondary (Class XII)
All Saints School (CBSE)
Ajmer, Rajasthan, India
July 2019– June2023
Ajmer, Rajasthan, India
2019
Ajmer, Rajasthan, India
Secondary (Class X)
CERTIfiCATIONS
2017
• Receivedrecognition for consistently exceeding expectations by demonstrating strong work ethic and aligning with
companycorevalues
• Awardedfortakingownershipandresolvingclientissuesefficientlythroughproactiveproblem-solvingandextraeffort
• NPTELCertificate—ProgramminginJava(IIT/NPTEL)

Expected Annual CTC(in Lakhs): 7
Current Annual CTC(in Lakhs): 3
Expected Annual CTC(INR): 700000
Current Annual CTC(INR): 300000
Expected Annual CTC(USD): 5000
Current Annual CTC(USD): 2000
Notice Period: 15 Days
Serving Notice Period: Yes
Last Working Day: 12 Aug
LWD: 12 Aug
English proficiency: 'Intermediate'
My maximum experience is 3 years only
"""
default_experience = "3"
sender_email = 'arishika382@gmail.com'
sender_password = 'cvwu lmez sibk lxzz'
recipient_email = 'arishika382@gmail.com'
resume_link = 'https://drive.google.com/file/d/1mIeApy5UveCynNlpVF3Jo75FCfJD0Rrv/view?usp=sharing'
# resume_path = r"C:\Users\ShashiShekhar\OneDrive - AIR INDIA LIMITED\Desktop\Personal\Apply\Shashi\Shashi\Shashi_s_Resume.pdf"
chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
search_jobs = [   "Software Engineer Java",
"Java Full Stack Developer",
            "Spring Boot Developer",
            "Spring Boot Java Developer",
            "Java Microservices Developer", "Java Developer",
                                                "Backend Developer Java",
                        "Java Engineer",
                        "Java Application Developer","Software Developer Java",
                                                 "Java Software Engineer",
            "Java API Developer","Java Backend Developer",
                    
    "Java REST API Developer",
    "Core Java Developer",
    "Java J2EE Developer",
    "Associate Java Developer",
    "Software Engineer Backend",
    "Backend Software Engineer",
    "Java Spring Boot",
    "Java Microservices",
    "Java AWS Developer",
    "Java Cloud Developer"
]